<script lang="ts">
  import ProofOfReading from '$lib/ProofOfReading.svelte';
</script>

<ProofOfReading />
